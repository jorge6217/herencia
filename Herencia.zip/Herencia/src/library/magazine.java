package library;
/*
Esta clase hereda los atributos de la clase padre Documents
*/
public class magazine extends Documents{
	private int year;
    private int number;
    
    public magazine(int ID, String title, String materia, int numeroEjemplares, boolean estado, int year, int number) {
        super(ID, title, materia, numeroEjemplares, estado);
        this.year=year;
        this.number=number;
    }
    /*
    Se generan los setters y getters
    */
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
    
	}


