package library;

public class Documents {
	private int ID;
	private String titulo;
	private String materia;
	private boolean estado;
	private int numeroEjemplares;
	
	
	public Documents(int iD2, String titulo2, String autor2, String editorial2, String materia2, boolean estado2,
			int numeroEjemplares2) {
		// TODO Auto-generated constructor stub
	}

	public Documents(int iD2, String titulo2, String materia2, int numeroEjemplares2, boolean estado2) {
		// TODO Auto-generated constructor stub
	}

	public void book() {
	}
	
	public void document(int ID, String titulo, String materia, boolean estado, int numeroEjemplares) {
		this.ID = ID;
		this.titulo = titulo;
		this.materia = materia;
		this.estado = estado;
		this.numeroEjemplares = numeroEjemplares;
	}
	/*
    Se generan los setters y getters
    */
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getMateria() {
		return materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	public boolean getEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public int getNumeroEjemplares() {
		return numeroEjemplares;
	}

	public void setNumeroEjemplares(int numeroEjemplares) {
		this.numeroEjemplares = numeroEjemplares;
	}
	

}
