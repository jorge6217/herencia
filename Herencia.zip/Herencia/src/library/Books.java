package library;
/*
Esta clase hereda los atributos de la clase padre Documents
*/
public class Books extends Documents{
	private String autor;
	private String edit;

	public Books(int ID, String titulo, String materia, boolean estado, int numeroEjemplares) {
		super(ID, titulo, materia, numeroEjemplares, estado);
		this.autor = autor;
		this.edit = edit;
	}
	/*
    Se generan los setters y getters
    */
	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEdit() {
		return edit;
	}

	public void setEdit(String edit) {
		this.edit = edit;
	}
	
	

}
