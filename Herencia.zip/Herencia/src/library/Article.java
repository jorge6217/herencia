package library;
/*
Esta clase hereda los atributos de la clase padre Documents
*/
public class Article extends Documents{
	private int arbitro;
	
	 public Article(int ID, String title, String materia, int numeroEjemplares, boolean estado,int arbitro) {
	        super(ID, title, materia, numeroEjemplares, estado);
	        this.arbitro=arbitro;
	 }
	  /*
	    Se generan los setters y getters
	    */

	public int getArbitro() {
		return arbitro;
	}

	public void setArbitro(int arbitro) {
		this.arbitro = arbitro;
	}
	 
}
