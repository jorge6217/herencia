/**
 *
 * @author Jorge Luis Lopez Zamora
 * carnet: 221038
 */
package library;

import java.util.ArrayList;
import java.util.Scanner;


public class driverProgram {
	/*
    Main 
    */
	public static void main(String[] args) {
		// Se genera un scanner y se crea un arraylist
		Scanner sc = new Scanner(System.in);
		ArrayList<Documents> documento = new ArrayList<Documents>();
		
		Menu();
		int opcion = sc.nextInt();
		while(opcion != 9) {
			if(opcion == 1) {
				System.out.println("Ingrese el ID del libro");
				int ID = sc.nextInt();
				System.out.println("Ingrese el titulo del libro");
				String titulo = sc.next();
				System.out.println("Ingrese el autor del libro");
				String autor = sc.next();
				System.out.println("Ingrese la editorial del libro");
				String editorial = sc.next();
				System.out.println("Ingrese la materia del libro");
				String materia = sc.next();
				System.out.println("Ingrese el estado del libro");
				boolean estado = sc.next() != null;
				System.out.println("Ingrese la cantidad de ejemplares del libro");
				int numeroEjemplares = sc.nextInt();
				Documents document = new Documents(ID, titulo, autor, editorial, materia, estado, numeroEjemplares);
				System.out.println("Se ha insertado el libro a la libreria!");
				Menu();
				opcion = sc.nextInt();
			}else if(opcion == 2) {
			     System.out.println("Ingrese el id para poder mostrar el titulo de la publicacion");
		           int ID =sc.nextInt();
		           Documents buscador = search(ID, Documents);
		           if(buscador != null){
		               System.out.println("El titulo del id ingresado es: "+buscador.getTitulo());
		             
		           }else{
		               System.out.println("NO existe un id dentro de la base de datos");
		           }	
			}else if(opcion == 3) {
			    System.out.println("Ingrese la materia que desea saber la cantidad");
		           String materia =sc.next();
		           int cant = sabercantidadmaterias(materia, Documents);
		           if (cant == 0){
		               System.out.println("no existe esa materia");
		           }else{
		               System.out.println("La cantidad de materias es de: "+ cant);
		           }
			}else if(opcion == 4) {
			       System.out.println("Prestar un documento");
	               System.out.println("Ingrese el ID del cliente: ");
	               String id = sc.next();
	               Clientes busc = valCliente(ID, Clientes);
	               if  (busc != null){
	                   System.out.println("Existe el cliente");
	                   System.out.println("Ingrese el Id del documento ");
	                   String Id = sc.next();
	                   Documents look = buscador(ID,Documentos);
	                   if (look != null){
	                       int total = look.getCant();
	                       int totaal = look.getnumeroEjemplares();                      
	                       if( total >= 5){
	                           System.out.println("no puede realizar prestamos");
	                       }else {
	                           totaal = totaal-1;
	                           total = total +1;
	                           busc.setCant(total);
	                           int prest = 5-total;
	                           System.out.println("Pestamos disponibles: " + prest);
	                       
	                       }System.out.println("Disponible ");
	                   }else{
	                       System.out.println("NO Disponible");
	                   }
	                       
	               }else{
	                   System.out.println("No se ha encontrado el cliente");
	               }
	               
	               
			}
		}

	}
	/*
    Se define el menu del programa
    */
	public static void Menu() {
		System.out.println("   ----MENU----");
		System.out.println("1. Insertar un documento ");
		System.out.println("2. Buscar libro por ID ");
		System.out.println("3. Calcular la cantidad de documentos por materia ");
		System.out.println("4. Prestar un documento ");
		System.out.println("5. Devolucion de un docuento ");
		System.out.println("6. Cantidad de documentos por tipo prestados a un cliente ");
		System.out.println("7. Cantidad de revistan que se poseen por materia ");
		System.out.println("8. Determinar si esta disponible el ejemplar de algun libro o articulo ");
		System.out.println("9. Salir ");
		System.out.println("________________________________________________________________________");
	}
	/*
    Se utilizara para validar el estado de algun documento
    */
	public static boolean validarDocumento(int valor){
        boolean estado;
        if (valor == 1){
            estado = true;
        }else {
            estado = false;
        }
        return estado;
	}
	/*
    Se utilizara para para buscar algun documento
    */
	public static Documents buscador(String id, ArrayList<Documents> libro){
        for (Documents search: libro ){
            if (search.getID().equals(ID)){
            return search;
            }
        }
        return null;
     }
	/*
    Se utilizara para obtener la cantidad de materias de los libros
    */
	public static int cantMaterias (String materia,ArrayList<Documents> Books){
	    int cont=0;
	    for (Documents searchma: Books ){
	            if (searchma.getMateria().equals(materia)){
	                cont = cont +1;
	        }
	            
	        } return cont;
	}
	/*
    Se utilizara para decirle al usuario la cantidad de prestamos de libros que tiene el cliente
    */
	public static String validarCantidades(int cant){
        int vc = 0;
        String message;
        if (cant <= 5 && cant >=0){
               vc = 5-cant;
         message = "Aun puede realizar el prestamo de "+vc+" documentos";
        
        }else {
            message = "Unicamente puede prestar 5 documentos";
        }
        return message;
	}
	/*
    Se utilizara para obtener los datos del cliente. Si el cliente no ha sido creado(no existe) se mostrara null
    */
	public static Clientes valCliente(int ID, ArrayList<Clientes> Clientes){
        for (Clientes search: Clientes ){
        	if (search.getID().equals(ID)){
            return search;
        }
        }
        return null;
    }
}
